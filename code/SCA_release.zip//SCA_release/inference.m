% Inputs:
%   X_tr,X_te (DxN): data points, for train and test respectively
%   S_tr, S_te (NxN): similarity matrix between points
%   model, MML model, includes
%   1) init_M, true_M(optional) (DxDxK): K distance metrics
%   2) theta (Kx1): noise parameters
%   pr: parameters
% 
% Outputs:
%   infered model
function [model Log] = inference(X_tr, S_tr, X_te, S_te, model, pr)

% function [M] = variationalEM(X_tr,S_tr,X_te,S_te,theta,pr)
Log = struct();
lambda = pr.lambda;
theta = model.theta;
% optimize over M
if pr.infer == 0
    M = model.init_M;
else
    L = model.init_L;
    M = compute_using_L(L);
end
D = size(M, 1);
K = size(M, 3);
N = size(X_tr, 2);

initial_M = M;
% output true/initial metrics if needed
if pr.textMatrix
    fileID = cell(K,1);
end
for k = 1:K
    if pr.textMatrix
        fileID{k} = fopen([pr.result_directory,'log',num2str(k),'.txt'],'w');
        fprintf(fileID{k}, 'True M_%d\n', k);
        printMatrix(fileID{k}, pr.trueM(:,:,k));
        fprintf(fileID{k}, 'Initial M_%d\n', k);
        printMatrix(fileID{k}, M(:,:,k));
    end
    
    if pr.plotMatrix
        figure(100);
        subplot(1,K,k);
        imagesc(pr.trueM(:,:,k));
        figure(101);
        subplot(1,K,k);
        imagesc(M(:,:,k));
    end
end
if pr.plotMatrix
    fig = figure(100);
    set(fig,'PaperPosition',[0 0 8 1.5]);
    print(fig, '-dpng', [pr.result_directory,'trueM.png']);
    fig = figure(101);
    set(fig,'PaperPosition',[0 0 8 1.5]);
    print(fig, '-dpng', [pr.result_directory,'initialM.png']);
end

% run EM steps
nIters = pr.no_iter;
objEM = zeros(nIters,K);
tr = zeros(nIters+1,1);
llh = zeros(nIters+1,1);
reg_llh = zeros(nIters+1,1);
acc = zeros(nIters+1,1);
acc_test = zeros(nIters+1,1);
total = N*(N-1)/2;

% evaluate the initial metrics
% 1. check the likelihood
llh(1) = compute_llh(X_tr,S_tr,M);
reg_llh(1) = llh(1) - lambda * trace(sum(M, 3));
fprintf('Initial M: reg lglikelihood %f\n', reg_llh(1));
% 2. quality of data generated the inferred metrics compared to real data
acc(1) = testPerformance(X_tr,S_tr,M,theta);
acc_test(1)=testPerformance(X_te,S_te,M,theta);
fprintf('Initial M: Percent correct = %d/%d = %f\n\n', round(total*acc(1)), total, acc(1));
fprintf('Initial M: correct in test = %d/%d = %f\n\n', round(total*acc_test(1)),total,acc_test(1));
tr(1) = trace(sum(M,3));
%     feature = constructFeature(X);
feature = [];
%     profile on;
for t = 1:nIters
    iter = t
    % e_step
    q = E_step(X_tr,S_tr,M,theta);
    
    % m_step
    pr.iter = t;
    if (pr.infer)
        [L,theta,objk] = M_step2(X_tr,S_tr,L,theta,q,lambda,pr);
        M = compute_using_L(L);
    else
        [M,theta,objk] = M_step(X_tr,feature,S_tr,M,theta,q,lambda,pr);
    end
    
    obj = sum(objk);
    objEM(t, :) = objk;
    
    % output the inferred metrics if needed
    if pr.plotMatrix && (mod(t,5)==1)
        for k = 1:K
            figure(k);
            subplot(ceil(nIters/25), 5, (t+4)/5);
            imagesc(M(:,:,k));
        end
    end
    if pr.textMatrix
        for k = 1:K
            fprintf(fileID{k}, 'm step done: %f \n', objk(k));
            fprintf(fileID{k}, 'Inferred M_%d\n', k);
            printMatrix(fileID{k}, M(:,:,k));
        end
        fprintf(fileID{k}, 'em step done: complete data lglikelihood %f\n\n', obj);
    end
    fprintf('em step done: complete data lglikelihood %f\n', obj);
    
    % evaluate the inferred metrics
    % 1. check the likelihood
    llh(t+1) = compute_llh(X_tr,S_tr,M);
    tr(t+1) = trace(sum(M,3));
    reg_llh(t+1) = llh(t+1) - lambda * tr(t+1);
    
    fprintf('em step done: reg lglikelihood %f\n', reg_llh(t+1));
    % 2. quality of data generated the inferred metrics compared to real data
    acc(t+1) = testPerformance(X_tr,S_tr,M,theta);
    acc_test(t+1) = testPerformance(X_te,S_te,M,theta);
    fprintf('Percent correct = %d/%d = %f\n\n', round(total*acc(t+1)), total, acc(t+1));
    fprintf('correct in test = %d/%d = %f\n\n', round(total*acc_test(t+1)),total,acc_test(t+1));
end


if pr.plotMatrix
    for k = 1:K
        fig = figure(k);
        set(fig,'PaperPosition',[0 0 9 1.5+1.8*(ceil(nIters/25)-1)]);
        print(fig, '-dpng', [pr.result_dir,'M_', num2str(k), '.png']);
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% record every information that is needed
% accuracy
Log.acc = acc;
Log.acc_test = acc_test;
% trace, llh, reg_llh, objEM
Log.trace = tr;
Log.llh = llh;
Log.reg_llh = reg_llh;
Log.objEM = objEM;
%
model.M = M;
model.infered_M = M;
end

% print matrix X to file fp 
function printMatrix(fp, X)
    [m,n] = size(X);
    for i = 1:m
        for j = 1:n
            fprintf(fp, '%9f ', X(i,j));
        end
        fprintf(fp, '\n');
    end
    fprintf(fp, '\n');
end

function feature = constructFeature(X)
    [D,N] = size(X);
    feature = zeros(D*D,N*(N-1)/2);
    cnt = 1;
    for i = 1:N;
        for j = i+1:N;
            v = X(:,i) - X(:,j);
            phi = v*v';
            phi = reshape(phi',[D*D,1]);
            feature(:,cnt) = phi;
            cnt = cnt + 1;
        end
    end
end

function M = compute_using_L(L)
    [d D K] = size(L);
    M = zeros(D,D,K);
    for k = 1:K;
        M(:,:,k) = L(:,:,k)'*L(:,:,k);
    end
end
function L = compute_using_M(M)
    [D D K] = size(M);
    L = zeros(D,D,K);
    
    for k = 1:K;
        [u s v] = svd(M(:,:,k));
        L(:,:,k) = u * sqrt(s) * u';
    end
end


