function EX_SCA()

% This code shows how to use SCA to learn similarity from synthetic data toy.mat.

% ref: Similarity Component Analysis.
% Changpinyo Soravit*, Kuan Liu*, and Fei Sha.
% Proceeding of Neural Information Processing Systems 2013.

% @Kuan Liu. Dec 2014. 

close all;
addpath data
addpath helpers
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% initialize the parameters
% parameters should contain all info about experiment settings
if (~exist('pr')),
    pr = struct();
    pr = set_params(pr);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% generate or load data sets 

result_path = pr.result_dir;
set_K = [5]; % 
for i = 1:1%pr.num_splits
    for j = 1:length(set_K);
        kk = set_K(j);
        pr.infered_K = kk;
        pr.result_dir = [result_path,'/',num2str(i),'_K=',num2str(kk)];
        mkdir(pr.result_dir);
        [X_tr, S_tr, X_de, S_de, X_te, S_te, L, pr] = load_data(pr, i);
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % model intialization
        model = init_model(L, pr);
        
        % inference
        [model Log] = inference(X_tr, S_tr, X_de, S_de, model, pr);
        
        output(pr, model, Log);
    end
end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
close all;
fclose all;
end




% the following function may be useful.. I don't know how to deal with them
% now
function L = compute_using_M(M)
    [D D K] = size(M);
    L = zeros(D,D,K);   
    for k = 1:K;
        [u s v] = svd(M(:,:,k));
        L(:,:,k) = u * sqrt(s) * u';
    end
    % debug
    LL= zeros(D,D,5);   
    for i = 1:5;
        LL(:,:,i)=L(:,:,1);
    end
    L = LL;
end

