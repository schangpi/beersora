% optimize the objective over L: do each L_k at a time
function [L,theta,objk] = M_step2(X,s,L,theta,q,lambda,pr)

    [D,N] = size(X);
    d = size(L, 1);
    K = size(L, 3);
    dim = d * D;
    iter = pr.iter;
    lbfgs = 1;
    
    % projected gradient method
    objk = zeros(K,1);
    nIters = 15;
    objective = zeros(K, nIters);
    for k = 1:K;
        step_average = 1; % used in line search 1
        old = struct();
        for t = 1:nIters;
            DD = compute_distance(X,L(:,:,k),2); % store all pairwised distance
            obj = computeObj(X,q(:,:,k),L(:,:,k),lambda); % objective
            % compute coefficients needed in gradient computation
            aa = (1 ./ (1 + exp(-DD)));
            TMPp = 0.5 * aa ./ (0.5 - aa) .* q(:,:,k) + aa.* (1-aa)./(aa-0.5);
            for nn = 1:N;
                TMPp(nn,nn)=0;
            end            
            % compute gradient          
            grad2 = compute_gradient(X,TMPp);
            grad3 = L(:,:,k) * grad2;
            grad = reshape(grad3',dim,1);

            % decent direction
            w = reshape(L(:,:,k)',dim,1);
            
            if lbfgs
                [dir old] = compute_direction(grad,w,t,old);
            else
                dir = grad;
            end
            
            %line search (backtracking line search -Armijo's rule)
            obj_old = obj; w_old = w;
            bt_alpha = 0.3;
            bt_beta = 0.8;
            step = 0.02;
            left = 0; right = 1;
            inner_prod = grad' * dir;
            r = 0;
            while left < right
                r = r + 1;
                step = step * bt_beta;
                w = w_old + step * dir;
                L(:,:,k) = reshape(w,D,d)';
                obj = computeObj(X,q(:,:,k),L(:,:,k),lambda);
                left = obj;
                right = obj_old + bt_alpha * step * inner_prod;
                if r > 50 
                    break;
                end
            end
            
            objective(k, t) = obj;
        end
        objk(k) = objective(k, end);
        fprintf('optimizing L %d done: %f \n', k, objk(k));
    end
    
    % plot the projected gradient objective if needed 
    if pr.plotProjGradLlh
        figure(102);
        for k = 1:K
            subplot(1, K, k);
            plot(objective(k,:));
        end
        fig = figure(102);
        set(fig,'PaperPosition',[0 0 5*K/3 1.5]);
        print(fig, '-dpng', [pr.result_directory,'proj_grad', num2str(iter), '.png']);
    end
end

% compute the objective given qk and Mk
function [obj] = computeObj(X,qk,Lk,lambda)
    N = size(X,2);
    D = compute_distance(X,Lk,2);
    J = qk .* (-log(1-exp(-D)) + log(2) - D) + (log(1-exp(-D)) - log(exp(-D)+1));
    J(eye(N)~=0) = 0;
    obj = ones(1,N) * J * ones(N,1)/2;
end

