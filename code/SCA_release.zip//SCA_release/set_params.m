function pr = set_params(pr)
% parameters include:
% 1)experiment settings: 
%   2-1)inference on L or M; 
%   2-2)how to initialize;
%   2-3)data set info: type, name and directory
% 2) hyper parameters
%    2-1) number of em iterations
% 3)debugging parameters: whether to plot something or not

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pr.filename = 'toy.mat'; 
pr.permfile = 'perm_ind.mat';
% working directory
pr.result_dir = ['output/',date()];
mkdir(pr.result_dir);

%toy data set or not
pr.toy = 1;

if (pr.toy)
    % size of splitting data set
    pr.no_train = 300;
    pr.no_dev = 100;
    pr.no_test = 100;
    pr.num_splits = 10;
    pr.dimension = 30;
    pr.true_K = 5;
    pr.infered_K = 5;
end;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% hyper parameters
% number of em iterations
pr.no_iter = 20; %50;
% regularizer coefficient
pr.lambda = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% initialize the matrix
% 0: random
% 1: oracle
% 2: oracle with noise
pr.initial = 0;
% optimization over M (0) or L (1)
% M = L^T * L
% inference over L or M
% 0 -- over M;
% 1 -- over L
pr.infer = 1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% print metrics in each iteration to file
pr.textMatrix = 0;
% plot metrics in each iteration
pr.plotMatrix = 0;
% plot
pr.plotProjGradLlh = 0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
