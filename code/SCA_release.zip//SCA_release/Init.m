classdef Init
    
    methods(Static, Access=public)
        
        function randomM = initialize_random(D,K)
            randomM = zeros(D,D,K);
            for k = 1:K
                L = normrnd(0, 6/D, [D D]);
                randomM(:,:,k) = L*L';
            end
        end
        
        function diagonalM = initialize_random_diagonal(D,K)
            diagonalM = zeros(D,D,K);
            ind = randperm(D);
            for k = 1:K;
                for i = (D/K)*(k-1)+1:(D/K)*k
                    diagonalM(ind(i),ind(i),k) = 1;
                end
            end
        end
        
        function noisyM = initialize_addnoise(M)
            [D,~,K] = size(M);
            noisyM = zeros(D,D,K);
            for k = 1:K
                L = normrnd(0, 6/D, [D D]);
                noisyM(:,:,k) = M(:,:,k) + L*L';
            end
        end
        
        function randomL = initialize_random_L(d,D,K)
            randomL = zeros(d,D,K);
            for k = 1:K
                randomL(:,:,k) = normrnd(0, 6/D, [d D]);
            end
        end
        
        function noisyL = initialize_addnoise_L(L)
            [D,~,K] = size(L);
            noisyL = zeros(D,D,K);
            for k = 1:K
                noisyL(:,:,k) = L(:,:,k) + normrnd(0,6/D, [D D]);
            end
        end
    end
end

