function [q] = E_step(X,s,M,theta)
    N = size(X, 2);
    K = size(M, 3);
    p = zeros(N,N,K);
    r = zeros(N,N,K);
    for k = 1:K
        Q = X' * M(:,:,k) * X;
        P = ones(N,1) * diag(Q)';
        D = P + P' - 2 * Q;
        p(:,:,k) = 2 - 2 * 1 ./ (1+exp(-D));
        r(:,:,k) = p(:,:,k) * (theta(k)-1)+1;
    end

    pie = ones(N,N);
    for k = 1:K
        pie = pie .* r(:,:,k);
    end
    
    % compute posterior q
    % q(i,j,k) is the probability of h_ijk = 1 conditioned on s = 0/1
    for k = 1:K
        for i = 1:N
            for j = i+1:N
                if (s(i,j) == 0)
                    q(i,j,k) = p(i,j,k) * theta(k) / r(i,j,k);
                else
                    if pie(i,j) == 1
                        q(i,j,k) = p(i,j,k);
                    else
                        q(i,j,k) = p(i,j,k) * (1 - pie(i,j) * theta(k) / r(i,j,k)) / (1 - pie(i,j));
                    end
                end
                q(j,i,k) = q(i,j,k);
            end
        end
    end
end