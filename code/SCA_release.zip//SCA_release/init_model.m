function model = init_model(L, pr)
% model includes metrics, noise(optional)
% 
D = pr.dimension;
K = pr.infered_K;

model = struct();

model.K = K;
model.theta = zeros(K, 1); %can be fixed later

M = compute_using_L(L);
model.true_M = M;
model.true_L = L;
model.init_M = [];
model.init_L = [];





% initialize L or M
if pr.infer == 0
    if pr.initial == 0
        model.init_M = Init.initialize_random(D,K);
    elseif pr.initial == 1
        model.init_M = M;
    elseif pr.initial == 2
        model.init_M = Init.initialize_addnoise(M);
    end
else
    if pr.initial == 0
        model.init_L = Init.initialize_random_L(30,D,K);
    else
        if  exist('L')
            for k = 1:K
                L(:,:,k) = L(:,:,k)';
            end
        else
            L = compute_using_M(M);
        end
        if pr.initial == 1
            model.init_L = L;
        elseif pr.initial == 2
            model.init_L = Init.initialize_addnoise_L(L);
        end
    end
end
if pr.infer
    model.L = model.init_L;
    model.M = compute_using_L(model.L);
else
    model.M = model.init_M;
    model.L = compute_using_M(model.M);
end
model.init_M = model.M;
model.init_L = model.L;

end

function M = compute_using_L(L)
    [d D K] = size(L);
    M = zeros(D,D,K);
    for k = 1:K;
        M(:,:,k) = L(:,:,k)'*L(:,:,k);
    end
end

function L = compute_using_M(M)
    [D D K] = size(M);
    L = zeros(D,D,K);   
    for k = 1:K;
        [u s v] = svd(M(:,:,k));
        L(:,:,k) = u * sqrt(s) * u';
    end
    % debug
    LL= zeros(D,D,5);   
    for i = 1:5;
        LL(:,:,i)=L(:,:,1);
    end
    L = LL;
end