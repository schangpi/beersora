% optimize the objective over M: do each M_k at a time
function [M,theta,objk] = M_step(X,feature,s,M,theta,q,lambda,pr)

    [D,N] = size(X);
    K = size(M, 3);
    beta = 0.5; % decrease step size by this factor
    iter = pr.iter;
    
    % projected gradient method
    objk = zeros(K,1);
    nIters = 15;
    objective = zeros(K, nIters);
    for k = 1:K;
        step_average = 1; % used in line search
        for t = 1:nIters;
            Q = X' * M(:,:,k) * X;
            P = ones(N,1) * diag(Q)';
            DD = P + P' - 2 * Q;
            obj = computeObj(X,q(:,:,k),M(:,:,k),lambda);
            % compute coefficients needed in grad computation
            aa = (1 ./ (1 + exp(-DD)));
            TMPp = 0.5 * aa ./ (0.5 - aa) .* q(:,:,k) + aa.* (1-aa)./(aa-0.5);
            for nn = 1:N;
                TMPp(nn,nn)=0;
            end
            
            
            % compute gradient          
%             grad = feature * TTmp;
            grad2 = compute_gradient(X,TMPp);
            grad = reshape(grad2',D*D,1)/2;


            
            obj_old = obj;
            w = reshape(M(:,:,k)',D*D,1);
            grad = grad - lambda * reshape(eye(D),D*D,1);
            wOld = w;
            % determine step size using line search
            step = step_average;
            for r = 0:30
                step = step * beta^r;
                % gradient ascent
                w = wOld + step * grad;
                % projection
                newm = reshape(w,D,D)';
                M(:,:,k) = psdProjection(newm);
                % compute objective, see if it is bigger
                obj = computeObj(X,q(:,:,k),M(:,:,k),lambda);
                if (obj > obj_old)
                    
                    break;
                end
            end       
            step_average = (step_average * (t-1) + step) / t;
            objective(k, t) = obj;
        end
        objk(k) = objective(k, end);
%         fprintf('projected gradient %d done: %f \n', k, objk(k));
    end
    
    % plot the projected gradient objective if needed 
    if pr.plotProjGradLlh
        figure(102);
        for k = 1:K
            subplot(1, K, k);
            plot(objective(k,:));
        end
        fig = figure(102);
        set(fig,'PaperPosition',[0 0 5*K/3 1.5]);
        print(fig, '-dpng', [pr.result_directory,'proj_grad', num2str(iter), '.png']);
    end
end

% given a vector v of length D
% return quadratic feature vector phi of length D*D
function [phi] = get_quad_features(v)
    D = length(v);
    phi = v*v';
    phi = reshape(phi', [D*D, 1]);
end

% given a square matrix M
% project it into PSD space
% first by finding a diagonalization X^T*diag[l1,...,lD]*X
% make diag[l1,...,lD] -> diag[max{0,l1},...,max{0,lD}]
function [M_new] = psdProjection(M_old)
    [V D] = eig(M_old);
    % eig produces matrices of eigenvalues (D) and eigenvectors (V) 
    % of matrix M_old, so that M_old*V = V*D. 
    dim = size(D,1);
    for i = 1:dim
        if D(i,i) < 0
            D(i,i) = 0;
        end
    end
    M_new = V*D*V';
end

% compute the objective given qk and Mk
function [obj] = computeObj(X,qk,Mk,lambda)
    N = size(X,2);
    Q = X' * Mk * X;
    P = ones(N,1) * diag(Q)';
    D = P + P' - 2 * Q;
    J = qk .* (-log(1-exp(-D)) + log(2) - D) + (log(1-exp(-D)) - log(exp(-D)+1));
    J(eye(N)~=0) = 0;
    obj = ones(1,N) * J * ones(N,1)/2;
    obj = obj - lambda * trace(Mk);
end

