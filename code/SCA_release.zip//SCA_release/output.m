function output(pr, model, Log)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% text file
% readme
print_readme([pr.result_dir,'/readme.txt'],pr);
% acc,llh
print_vec([pr.result_dir,'/train_acc.txt'],Log.acc);
print_vec([pr.result_dir,'/test_acc.txt'],Log.acc_test);
print_vec([pr.result_dir,'/reg_llh.txt'],Log.reg_llh);
print_vec([pr.result_dir,'/trace.txt'],Log.trace);
print_vec([pr.result_dir,'/llh.txt'],Log.llh);
print_vec([pr.result_dir,'/objEM.txt'],Log.objEM);
% M,L
% infered M,L
K = model.K;
for k = 1:K;
    print_matrix([pr.result_dir,'/metric_',int2str(k),'.txt'],model.M(:,:,k));
    print_matrix([pr.result_dir,'/L_',int2str(k),'.txt'],model.L(:,:,k));
end
print_metric_all([pr.result_dir,'/metrics.txt'],model.M);
print_metric_all([pr.result_dir,'/Ls.txt'],model.L);
% initial M,L
for k = 1:K;
    if (~pr.infer)
        print_matrix([pr.result_dir,'/init_metric_',int2str(k),'.txt'],model.init_M(:,:,k));
    end
    print_matrix([pr.result_dir,'/init_L_',int2str(k),'.txt'],model.init_L(:,:,k));
end
print_metric_all([pr.result_dir,'/init_metrics.txt'],model.init_M);
print_metric_all([pr.result_dir,'/init_Ls.txt'],model.init_L);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% plot 
% % initial/final/true M
% plot_metric_1(pr,model);
% plot each metric
for k = 1:K
    plot_metric_2([pr.result_dir,'/metric_',int2str(k),'.png'],model.M(:,:,k));
end
% predictive performance
plot_prediction(pr,Log);
% reg_llh vs train_acc
plot_prediction_vs_regllh(pr,Log);
% reg_llh vs trace
plot_regllh_vs_trace(pr,Log);
% %plot one metric (the first)
% fig = figure(500);
% subplot(1,1,1)
% imagesc(model.M(:,:,1));
% print(fig,'-dpng', [pr.result_directory,'final_metric.png']);

end

function plot_metric_2(filename,A)
fig = figure(500)
subplot(1,1,1);
imagesc(A);
print(fig,'-dpng',filename);
end

function plot_metric_1(pr,model)
fig = figure('name','matrix:(initial/infered/true)');
K = model.K;
for im = 1:K;
    subplot(3,K,im);
    imagesc(model.init_M(:,:,im));
    subplot(3,K,im+K);
    imagesc(model.M(:,:,im));
    subplot(3,K,im+2*K);
    if im <= size(model.true_M,3)
        imagesc(model.true_M(:,:,im));
    end
end
saveas(fig,[pr.result_dir,'/matrix(initial_infered_true).png']);
end

function plot_regllh_vs_trace(pr,Log)
fig = figure(201);
subplot(1,2,1)
plot(Log.trace);
ylabel('trace');
subplot(1,2,2);
plot(Log.reg_llh);
ylabel('reg_-llh');
set(fig,'PaperPosition',[0 0 6 3]);
print(fig, '-dpng', [pr.result_dir,'/regllh_vs_trace.png']);
end

function plot_prediction_vs_regllh(pr,Log)
fig = figure(200);
subplot(1, 2, 1)
plot(Log.acc);
ylabel('train_-accuracy');
subplot(1, 2, 2);
Log.reg_llh(Log.reg_llh == -Inf) = NaN;
plot(Log.reg_llh);
ylabel('reg_-log likelihood');
set(fig,'PaperPosition',[0 0 6 3]);
print(fig, '-dpng', [pr.result_dir,'/prediction_vs_regllh.png']);
end

function plot_prediction(pr,Log)
fig = figure(202);
subplot(1,2,1)
plot(Log.acc);
ylabel('train_-acc');
subplot(1,2,2);
plot(Log.acc_test);
ylabel('test_-acc');
set(fig,'PaperPosition',[0 0 6 3]);
print(fig, '-dpng', [pr.result_dir,'/train_-test_-acc.png']);
end

function print_metric_all(filename,A)
% A can be M or L
f = fopen(filename,'w','n','GBK');
[m n K] = size(A);
for k = 1:K;
    for i = 1:m;
        for j = 1:n;
            fprintf(f,'%5f ',A(i,j,k));
        end
        fprintf(f,'\n');
    end
    fprintf(f,'\n\n');
end
fclose(f);
end

function print_vec(filename,vec)
f = fopen(filename,'w','n','GBK');
for i = 1:length(vec)
    fprintf(f,'%5f\n',vec(i));
end
fprintf(f,'\n');
fclose(f);
end

function print_matrix(filename,matrix)
f = fopen(filename,'w','n','GBK');
[m n] = size(matrix);
for i = 1:m
    for j = 1:n
        fprintf(f,'%5f ',matrix(i,j));
    end
    fprintf(f,'\n');
end
fprintf(f,'\n');
fclose(f);
end

function print_readme(filename,pr)
f = fopen(filename,'w','n','GBK');
fprintf(f,'data used: %s\n',pr.filename);
fprintf(f,'data dimension: %d\n',pr.dimension);
fprintf(f,'data set size: %d/%d/%d\n',pr.no_train,pr.no_dev,pr.no_test);
fprintf(f,'lambda: %d\n',pr.lambda);
fprintf(f,'Iteration number: %d\n',pr.no_iter);
if pr.infer
    D = pr.dimension;
    fprintf(f,'???optimizing using L of dimension [%d %d] \n',D,D);
else
    fprintf(f,'optimizing using M \n');
end
if pr.initial == 0
    fprintf(f,'initialization: random\n');
elseif pr.initial == 1
    fprintf(f,'initialization: oracle\n');
else
    fprintf(f,'initialization: oracle with noise\n');
end
fprintf(f,'true number of metrics:     K =%d\n',pr.true_K);
fprintf(f,'inferred number of metrics: K =%d\n',pr.infered_K);
fclose(f);
end