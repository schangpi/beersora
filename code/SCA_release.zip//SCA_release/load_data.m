function [X_tr, S_tr, X_de, S_de, X_te, S_te, L, pr] = load_data(pr, i)
    load(pr.filename);
    load(pr.permfile);
    n = size(X, 2);
    pr.dimension = size(X,1);
    n1 = pr.no_train;
    n2 = pr.no_train + pr.no_dev;
    n3 = pr.no_train + pr.no_dev + pr.no_test;
    ind1 = ind(i, 1:n1);
    ind2 = ind(i, n1+1:n2);
    ind3 = ind(i, n2+1:n3);
    X_tr = X(:, ind1);
    X_de = X(:, ind2);
    X_te = X(:, ind3);
    S_tr = s(ind1, ind1);
    S_de = s(ind2, ind2);
    S_te = s(ind3, ind3);
    if (exist('L'))
        L = L;
    else
        L = compute_using_M(M);
    end 
    pr.true_K = size(L,3);
end



function L = compute_using_M(M)
    [D D K] = size(M);
    L = zeros(D,D,K);   
    for k = 1:K;
        [u s v] = svd(M(:,:,k));
        L(:,:,k) = u * sqrt(s) * u';
    end
end
