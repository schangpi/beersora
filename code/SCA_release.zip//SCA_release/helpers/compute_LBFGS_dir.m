function d =compute_LBFGS_dir(q, old)

    M = length(old.rho);
    alpha = zeros(M,1);
    beta  = zeros(M,1);

    for i=M:-1:1,
        alpha(i) = old.rho(i)*old.s(:,i)'*q;
        q = q - alpha(i)*old.y(:,i);
    end
    if any(isnan(alpha))
        keyboard;
    end

    z = -q; % initial Hessian is -eye
    for i=1:M,
        beta(i) = old.rho(i)*old.y(:,i)'*z;
        z = z + old.s(:,i)*(alpha(i) - beta(i));
    end
    

    d = -z; %;/ norm(z,2);
    if any(isnan(d))
        keyboard;
    end

end