function [dir old] = compute_direction(grad,x_new,t,old)
    % by default
    dir = grad;
    % L-BFGS
    if t > 1 
        
        s = x_new - old.x;        
        y = grad - old.g;
        rho = 1/(s'*y);
        old.info.s(:,end+1)=s;
        old.info.y(:,end+1)=y;
        old.info.rho(end+1)=rho;
        p = 1;
        q = grad * p + (1-p) * old.g;
        dir = compute_LBFGS_dir(q,old.info);
    else
        old.info.s = [];
        old.info.y = [];
        old.info.rho=[];
       
    end
    old.x = x_new;
    old.g = grad;
    
end