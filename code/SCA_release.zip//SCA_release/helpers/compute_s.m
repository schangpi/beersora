% compute similarity given X and M
% without considering theta!
function s = compute_s(X,M,theta,verb)
    if nargin < 4
        verb = 0;
    end

    K = size(M, 3);
    N = size(X, 2);
    log_s0 = zeros(N,N);
    threshold = 0.5;
    % compute distance between data points
    dis = zeros(N,N,K);
    if verb
        tedges = N*(N-1)/2;
        fprintf('Total number of edges possible: %d\n', tedges);
    end
    for k = 1:K
        Q = X' * M(:,:,k) * X;
        P = ones(N,1) * diag(Q)';
        dis(:,:,k) = P + P' - 2 * Q;
        log_pk0 = log(1-exp(-dis(:,:,k))) - log(1+exp(-dis(:,:,k)));
        if verb
            nedges = sum(sum(1-exp(log_pk0)))/2;
            fprintf('Expected number of edges for M_%d = %.2f (%.2f %%)\n', k, nedges, nedges/tedges*100);
        end
        log_s0 = log_s0 + log_pk0;
    end
    s = log_s0 < log(threshold);
    s(eye(N)~=0) = 0;
    if verb
        nedges = sum(sum(s))/2;
        fprintf('Number of edges = %d (%.2f %%)\n', nedges, nedges/tedges*100);
    end
end