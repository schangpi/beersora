function [D] = compute_distance(X,L,opt);
    N = size(X,2);
    if (opt == 2)
        Q = X' * L'*L * X;
    else if (opt == 1)
            Q = X' * L' * X;
        end
    end
    P = ones(N,1) * diag(Q)';
    D = P + P' - 2 * Q;
end