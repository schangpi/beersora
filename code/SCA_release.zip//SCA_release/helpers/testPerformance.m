% given X, M, and theta, compute similarity between datapoints and
% compare it with the true similarity s
function [accuracy] = testPerformance(X,s,M,theta)
    N = size(X,2);
    total = N*(N-1)/2;
    pred = compute_s(X,M,theta,0);
    nedges = sum(sum(pred));
    % bad metrics warning
    if nedges == 0
        fprintf('Warning: bad metrics, predicting all zeros\n');
    end
    if nedges == N*N
        fprintf('Warning: bad metrics, predicting all ones\n');
    end
    correct = (sum(sum(s == pred)) - sum(sum(diag(s) == diag(pred))))/2;
    accuracy = correct/total;
end