% given design matrix X and T
% grad = \sum_ij T_ij * (Xi-Xj)*(Xi-Xj)'
% equivalently,
% grad = XSX' - XTX' - XT'X'
% where S_ij=T_ij if i == j else S_ij = 0;
function [gradient] = compute_gradient(X,T)
[D,N] = size(X);
S = zeros(N,N);
for i = 1:N;
    S(i,i) = sum(T(i,:))+sum(T(:,i));
end
gradient = X*S*X' - X*T*X' - X*T'*X';
end