% compute log likelihood given theta = 0
% likelihood function p(S|X,M,Theta) = \prod p(s_ij|X,M,Theta)

function llh = compute_llh(X,s,M)
    K = size(M, 3);
    N = size(X, 2);
    log_h0 = zeros(N,N,K);
    for k = 1:K
        Q = X' * M(:,:,k) * X;
        P = ones(N,1) * diag(Q)';
        D = P + P' - 2 * Q;
        log_h0(:,:,k) = log(1-exp(-D))-log(1+exp(-D));
    end
    
    % then compute log p(s=0|X,M) [represented by new log_h0]
    % here we implicitly make use of 
      % p(s=0|X,M) = \prod p(h_k|X,M)
      % p(s=1|X,M) = 1 - p(s=0|X,M)
    % which doesn't hold when there is 'noise' TODO
    log_h0 = sum(log_h0, 3);
    log_h1 = log(1-exp(log_h0));
    log_h0(s == 1) = 0;
    log_h1(s == 0) = 0;
    log_h0(s == -1) = 0;
    log_h1(s == -1) = 0;
    log_h0(eye(N)~=0) = 0;
    log_h1(eye(N)~=0) = 0;
    llh = (s == 0).*log_h0 + (s == 1).*log_h1;
    llh = sum(sum(llh))/2;
end

function llh = compute_llh2(X,s,M)
    K = size(M, 3);
    N = size(X, 2);
    llh = zeros(K,1);
    for k = 1:K
        Q = X' * M(:,:,k) * X;
        P = ones(N,1) * diag(Q)';
        D = P + P' - 2 * Q;
        log_h0 = log(1-exp(-D))-log(1+exp(-D));
        log_h1 = log(1 - exp(log_h0));
        log_h0(s == 1) = 0;
        log_h1(s == 0) = 0;
        log_h0(eye(N)~=0) = 0;
        log_h1(eye(N)~=0) = 0;
        llh_k = (1-s) .* log_h0 + s .* log_h1;         
        llh(k) = ones(1,N) * llh_k * ones(N,1)/2;
    end
    llh = sum(llh);
end